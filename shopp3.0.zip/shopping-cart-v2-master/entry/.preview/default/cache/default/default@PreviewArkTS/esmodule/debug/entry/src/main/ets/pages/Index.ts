if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
import util from "@ohos:util";
import promptAction from "@ohos:promptAction";
import type { BusinessError } from "@ohos:base";
@ObservedV2
class ProductItem {
    id: string = util.generateRandomUUID();
    image: Resource = { "id": 16777236, "type": 20000, params: [], "bundleName": "com.example.shoppingcartv2", "moduleName": "entry" };
    @Trace
    name: ResourceStr = ''; // 商品名称
    @Trace
    checked: boolean = false; // 选中状态
    @Trace
    price: number = 0; // 商品价格
    @Trace
    count: number = 0; // 商品数量
    constructor(image: Resource, name: ResourceStr, price: number) {
        this.image = image;
        this.name = name;
        this.price = price;
    }
}
class TitleView extends ViewV2 {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda, extraInfo) {
        super(parent, elmtId, extraInfo);
        this.deleteProduct = "deleteProduct" in params ? params.deleteProduct : () => {
        };
        this.addProduct = "addProduct" in params ? params.addProduct : () => {
        };
        this.finalizeConstruction();
    }
    public resetStateVarsOnReuse(params: Object): void {
        this.deleteProduct = "deleteProduct" in params ? params.deleteProduct : () => {
        };
        this.addProduct = "addProduct" in params ? params.addProduct : () => {
        };
    }
    @Event
    deleteProduct: () => void;
    @Event
    addProduct: () => void;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(44:5)", "entry");
            Row.backgroundColor('rgba(241,243,245,0.8)');
            Row.backdropBlur(80);
            Row.padding({
                // 内边距
                top: 36,
                left: 16,
                right: 16,
                bottom: 14
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(45:7)", "entry");
            Row.width('100%');
            Row.height(56);
            Row.justifyContent(FlexAlign.SpaceBetween);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('购物车');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(47:9)", "entry");
            Text.fontSize(26);
            Text.fontWeight(700);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 8 });
            Row.debugLine("entry/src/main/ets/pages/Index.ets(51:9)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/Index.ets(52:11)", "entry");
            Button.width(40);
            Button.height(40);
            Button.borderRadius(20);
            Button.backgroundColor('rgba(0,0,0,0.05)');
            Button.onClick(() => this.addProduct());
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            SymbolGlyph.create({ "id": 125831481, "type": 40000, params: [], "bundleName": "com.example.shoppingcartv2", "moduleName": "entry" });
            SymbolGlyph.debugLine("entry/src/main/ets/pages/Index.ets(53:13)", "entry");
            SymbolGlyph.fontSize(24);
            SymbolGlyph.fontColor([Color.Black]);
        }, SymbolGlyph);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/Index.ets(63:11)", "entry");
            Button.width(40);
            Button.height(40);
            Button.borderRadius(20);
            Button.backgroundColor('rgba(0,0,0,0.05)');
            Button.onClick(() => this.deleteProduct());
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // $r('资源路径') 静态资源引用语法。 应用资源：$r('app.type.name')  系统资源：$r('sys.type.resource_id')
            // SymbolGlyph显示图标小符号的组件
            SymbolGlyph.create({ "id": 125831542, "type": 40000, params: [], "bundleName": "com.example.shoppingcartv2", "moduleName": "entry" });
            SymbolGlyph.debugLine("entry/src/main/ets/pages/Index.ets(66:13)", "entry");
            // $r('资源路径') 静态资源引用语法。 应用资源：$r('app.type.name')  系统资源：$r('sys.type.resource_id')
            // SymbolGlyph显示图标小符号的组件
            SymbolGlyph.fontSize(24);
            // $r('资源路径') 静态资源引用语法。 应用资源：$r('app.type.name')  系统资源：$r('sys.type.resource_id')
            // SymbolGlyph显示图标小符号的组件
            SymbolGlyph.fontColor([Color.Black]);
        }, SymbolGlyph);
        Button.pop();
        Row.pop();
        Row.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class ProductItemView extends ViewV2 {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda, extraInfo) {
        super(parent, elmtId, extraInfo);
        this.initParam("productItem", (params && "productItem" in params) ? params.productItem : new ProductItem({ "id": 16777236, "type": 20000, params: [], "bundleName": "com.example.shoppingcartv2", "moduleName": "entry" }, '', 0));
        this.countChange = () => {
        };
        this.finalizeConstruction();
    }
    public resetStateVarsOnReuse(params: Object): void {
        this.resetParam("productItem", (params && "productItem" in params) ? params.productItem : new ProductItem({ "id": 16777236, "type": 20000, params: [], "bundleName": "com.example.shoppingcartv2", "moduleName": "entry" }, '', 0));
        this.resetConsumer("countChange", () => {
        });
    }
    @Param
    readonly productItem: ProductItem;
    @Consumer('countChange')
    countChange: (id: string, operation: string) => void;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(102:5)", "entry");
            Row.width('100%');
            Row.height(104);
            Row.borderRadius(16);
            Row.padding(12);
            Row.backgroundColor(Color.White);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(103:7)", "entry");
            Column.width(112);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(104:9)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Checkbox.create();
            Checkbox.debugLine("entry/src/main/ets/pages/Index.ets(105:11)", "entry");
            Checkbox.select({ value: this.productItem.checked, $value: newValue => { this.productItem.checked = newValue; } });
            Checkbox.width(20);
            Checkbox.height(20);
            Checkbox.margin(2);
        }, Checkbox);
        Checkbox.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create(this.productItem.image);
            Image.debugLine("entry/src/main/ets/pages/Index.ets(111:11)", "entry");
            Image.width(76);
            Image.height(76);
            Image.borderRadius(16);
            Image.margin({ left: 12 });
        }, Image);
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(120:7)", "entry");
            Column.layoutWeight(1);
            Column.margin({ left: 12 });
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(121:9)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(122:11)", "entry");
            Column.alignItems(HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.productItem.name);
            Text.debugLine("entry/src/main/ets/pages/Index.ets(123:13)", "entry");
            Text.height(21);
            Text.fontColor('rgba(0,0,0,0.9)');
            Text.fontSize(16);
            Text.fontWeight(500);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('旅行');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(129:13)", "entry");
            Text.height(16);
            Text.fontColor('rgba(0,0,0,0.4)');
            Text.fontSize(12);
            Text.fontWeight(400);
        }, Text);
        Text.pop();
        Column.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(140:9)", "entry");
            Row.height(24);
            Row.margin({ top: 19, right: 0 });
            Row.justifyContent(FlexAlign.SpaceBetween);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(141:11)", "entry");
            Row.layoutWeight(1);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('￥');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(142:13)", "entry");
            Text.fontColor('rgba(0,0,0,0.9)');
            Text.fontWeight(700);
            Text.fontSize(12);
            Text.margin({ top: 4 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.productItem.price.toString());
            Text.debugLine("entry/src/main/ets/pages/Index.ets(147:13)", "entry");
            Text.fontColor('rgba(0,0,0,0.9)');
            Text.fontWeight(700);
            Text.fontSize(16);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(156:11)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/Index.ets(157:13)", "entry");
            Button.width(30);
            Button.height(30);
            Button.borderRadius(15);
            Button.backgroundColor(Color.White);
            Button.enabled(this.productItem.count > 0 ? true : false);
            Button.onClick(() => {
                this.countChange(this.productItem.id, 'subtract');
            });
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            SymbolGlyph.create({ "id": 125831485, "type": 40000, params: [], "bundleName": "com.example.shoppingcartv2", "moduleName": "entry" });
            SymbolGlyph.debugLine("entry/src/main/ets/pages/Index.ets(158:15)", "entry");
            SymbolGlyph.fontSize(26);
            SymbolGlyph.fontColor(['rgba(10,89,247,1)']);
        }, SymbolGlyph);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.productItem.count.toString());
            Text.debugLine("entry/src/main/ets/pages/Index.ets(172:13)", "entry");
            Text.width(30);
            Text.height(30);
            Text.textAlign(TextAlign.Center);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/Index.ets(179:13)", "entry");
            Button.width(30);
            Button.height(30);
            Button.borderRadius(15);
            Button.backgroundColor(Color.White);
            Button.onClick(() => this.countChange(this.productItem.id, 'add'));
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            SymbolGlyph.create({ "id": 125831482, "type": 40000, params: [], "bundleName": "com.example.shoppingcartv2", "moduleName": "entry" });
            SymbolGlyph.debugLine("entry/src/main/ets/pages/Index.ets(180:15)", "entry");
            SymbolGlyph.fontSize(26);
            SymbolGlyph.fontColor(['rgba(10,89,247,1)']);
        }, SymbolGlyph);
        Button.pop();
        Row.pop();
        Row.pop();
        Column.pop();
        Row.pop();
    }
    public updateStateVars(params) {
        if (params === undefined) {
            return;
        }
        if ("productItem" in params) {
            this.updateParam("productItem", params.productItem);
        }
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class ProductListView extends ViewV2 {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda, extraInfo) {
        super(parent, elmtId, extraInfo);
        this.initParam("productList", (params && "productList" in params) ? params.productList : []);
        this.finalizeConstruction();
    }
    public resetStateVarsOnReuse(params: Object): void {
        this.resetParam("productList", (params && "productList" in params) ? params.productList : []);
        this.resetMonitorsOnReuse();
    }
    @Param
    readonly productList: ProductItem[];
    @Monitor('productList')
    onProductListChange() {
        // 监听productList变化，触发UI刷新
    }
    // @Builder装饰器用于封装可复用的UI结构
    itemHead(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/Index.ets(221:5)", "entry");
            Blank.margin({ top: 106 });
        }, Blank);
        Blank.pop();
    }
    // @Builder装饰器用于封装可复用的UI结构
    itemFooter(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/Index.ets(228:5)", "entry");
            Blank.margin({ top: 84 });
        }, Blank);
        Blank.pop();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(233:5)", "entry");
            Column.margin({
                left: 16,
                right: 16
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // space用于设置列表子项之间的距离
            List.create({ space: 12 });
            List.debugLine("entry/src/main/ets/pages/Index.ets(235:7)", "entry");
            // space用于设置列表子项之间的距离
            List.width('100%');
            // space用于设置列表子项之间的距离
            List.height('100%');
            // space用于设置列表子项之间的距离
            List.scrollBar(BarState.Off);
            // space用于设置列表子项之间的距离
            List.sticky(StickyStyle.Header);
        }, List);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ListItemGroup.create({
                // ListItemGroup用来展示列表item分组
                header: this.itemHead.bind(this),
                footer: this.itemFooter.bind(this)
            });
            ListItemGroup.debugLine("entry/src/main/ets/pages/Index.ets(236:9)", "entry");
            ListItemGroup.divider({ strokeWidth: 12, color: '#F1F3F5' });
        }, ListItemGroup);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 对商品列表进行循环渲染
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const productItem = _item;
                {
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        ListItem.create(deepRenderFunction, true);
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        ListItem.create(deepRenderFunction, true);
                        ListItem.debugLine("entry/src/main/ets/pages/Index.ets(243:13)", "entry");
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                if (isInitialRender) {
                                    let componentCall = new ProductItemView(this, {
                                        productItem: productItem
                                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 244, col: 15 });
                                    ViewV2.create(componentCall);
                                    let paramsLambda = () => {
                                        return {
                                            productItem: productItem
                                        };
                                    };
                                    componentCall.paramsGenerator_ = paramsLambda;
                                }
                                else {
                                    this.updateStateVarsOfChildByElmtId(elmtId, {
                                        productItem: productItem
                                    });
                                }
                            }, { name: "ProductItemView" });
                        }
                        ListItem.pop();
                    };
                    this.observeComponentCreation2(itemCreation2, ListItem);
                    ListItem.pop();
                }
            };
            this.forEachUpdateFunction(elmtId, this.productList, forEachItemGenFunction, (productItem: ProductItem) => productItem.id, false, false);
        }, ForEach);
        // 对商品列表进行循环渲染
        ForEach.pop();
        ListItemGroup.pop();
        // space用于设置列表子项之间的距离
        List.pop();
        Column.pop();
    }
    public updateStateVars(params) {
        if (params === undefined) {
            return;
        }
        if ("productList" in params) {
            this.updateParam("productList", params.productList);
        }
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class StatisticsView extends ViewV2 {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda, extraInfo) {
        super(parent, elmtId, extraInfo);
        this.initParam("buyCount", (params && "buyCount" in params) ? params.buyCount : 0);
        this.initParam("money", (params && "money" in params) ? params.money : 0);
        this.isAllChecked = false;
        this.allCheckedChange = "allCheckedChange" in params ? params.allCheckedChange : () => {
        };
        this.finalizeConstruction();
    }
    public resetStateVarsOnReuse(params: Object): void {
        this.resetParam("buyCount", (params && "buyCount" in params) ? params.buyCount : 0);
        this.resetParam("money", (params && "money" in params) ? params.money : 0);
        this.isAllChecked = false;
        this.allCheckedChange = "allCheckedChange" in params ? params.allCheckedChange : () => {
        };
    }
    @Param
    readonly buyCount: number;
    @Param
    readonly money: number;
    @Local
    isAllChecked: boolean;
    @Event
    allCheckedChange: (isAllChecked: boolean) => void;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(274:5)", "entry");
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceBetween);
            Row.backgroundColor('rgba(241,243,245,0.8)');
            Row.backdropBlur(80);
            Row.padding({
                left: 16,
                right: 16,
                top: 8,
                bottom: 36
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(275:7)", "entry");
            Row.width(80);
            Row.height(24);
            Row.onClick(() => {
                this.isAllChecked = !this.isAllChecked;
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Checkbox.create();
            Checkbox.debugLine("entry/src/main/ets/pages/Index.ets(276:9)", "entry");
            Checkbox.select({ value: this.isAllChecked, $value: newValue => { this.isAllChecked = newValue; } });
            Checkbox.width(20);
            Checkbox.height(20);
            Checkbox.margin({
                left: 2,
                top: 2,
                right: 5,
                bottom: 2
            });
            Checkbox.onChange(() => this.allCheckedChange(this.isAllChecked));
        }, Checkbox);
        Checkbox.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('全选');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(288:9)", "entry");
            Text.fontSize(16);
            Text.fontWeight(400);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(298:7)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('总计');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(299:9)", "entry");
            Text.fontSize(14);
            Text.fontWeight(400);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('￥');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(303:9)", "entry");
            Text.fontSize(14);
            Text.fontWeight(500);
            Text.fontColor('rgba(10,89,247,1)');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.money.toString());
            Text.debugLine("entry/src/main/ets/pages/Index.ets(308:9)", "entry");
            Text.fontSize(18);
            Text.fontWeight(500);
            Text.fontColor('rgba(10,89,247,1)');
            Text.margin({ right: 9 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel(`结算 (${this.buyCount})`);
            Button.debugLine("entry/src/main/ets/pages/Index.ets(314:9)", "entry");
            Button.width(120);
            Button.height(40);
            Button.fontSize(18);
            Button.fontWeight(500);
        }, Button);
        Button.pop();
        Row.pop();
        Row.pop();
    }
    public updateStateVars(params) {
        if (params === undefined) {
            return;
        }
        if ("buyCount" in params) {
            this.updateParam("buyCount", params.buyCount);
        }
        if ("money" in params) {
            this.updateParam("money", params.money);
        }
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class ShoppingCart extends ViewV2 {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda, extraInfo) {
        super(parent, elmtId, extraInfo);
        this.money = 0;
        this.productList = [
            new ProductItem({ "id": 16777240, "type": 20000, params: [], "bundleName": "com.example.shoppingcartv2", "moduleName": "entry" }, '瑞士滑雪', 16666),
            new ProductItem({ "id": 16777238, "type": 20000, params: [], "bundleName": "com.example.shoppingcartv2", "moduleName": "entry" }, 'Emerald Lake', 28898)
        ];
        this.customDialogId = 0;
        this.customProductName = '';
        this.customProductPrice = '';
        this.selectedImageIndex = 0;
        this.productImages = [
            { "id": 16777236, "type": 20000, params: [], "bundleName": "com.example.shoppingcartv2", "moduleName": "entry" },
            { "id": 16777235, "type": 20000, params: [], "bundleName": "com.example.shoppingcartv2", "moduleName": "entry" },
            { "id": 16777240, "type": 20000, params: [], "bundleName": "com.example.shoppingcartv2", "moduleName": "entry" },
            { "id": 16777238, "type": 20000, params: [], "bundleName": "com.example.shoppingcartv2", "moduleName": "entry" },
            { "id": 16777237, "type": 20000, params: [], "bundleName": "com.example.shoppingcartv2", "moduleName": "entry" }
        ];
        this.countChange = (id, operation) => {
            // 遍历商品列表
            for (let i = 0; i < this.productList.length; i++) {
                // 找到与传入商品id相同的商品
                if (this.productList[i].id === id) {
                    // 如果传入操作符为“add”将其数量加一，否则减一
                    if (operation === 'add') {
                        this.productList[i].count++;
                    }
                    else {
                        if (this.productList[i].count > 0) {
                            this.productList[i].count--;
                        }
                    }
                }
            }
        };
        this.finalizeConstruction();
    }
    public resetStateVarsOnReuse(params: Object): void {
        this.money = 0;
        this.productList = [
            new ProductItem({ "id": 16777240, "type": 20000, params: [], "bundleName": "com.example.shoppingcartv2", "moduleName": "entry" }, '瑞士滑雪', 16666),
            new ProductItem({ "id": 16777238, "type": 20000, params: [], "bundleName": "com.example.shoppingcartv2", "moduleName": "entry" }, 'Emerald Lake', 28898)
        ];
        this.customDialogId = 0;
        this.customProductName = '';
        this.customProductPrice = '';
        this.selectedImageIndex = 0;
        this.resetComputed("buyCount");
        this.countChange = (id, operation) => {
            // 遍历商品列表
            for (let i = 0; i < this.productList.length; i++) {
                // 找到与传入商品id相同的商品
                if (this.productList[i].id === id) {
                    // 如果传入操作符为“add”将其数量加一，否则减一
                    if (operation === 'add') {
                        this.productList[i].count++;
                    }
                    else {
                        if (this.productList[i].count > 0) {
                            this.productList[i].count--;
                        }
                    }
                }
            }
        };
        this.resetMonitorsOnReuse();
    }
    @Local
    money: number;
    @Local
    productList: ProductItem[];
    // 对话框相关状态
    @Local
    customDialogId: number;
    @Local
    customProductName: string;
    @Local
    customProductPrice: string;
    @Local
    selectedImageIndex: number;
    // 可用的商品图片
    private readonly productImages: Resource[];
    // 自定义对话框的 @Builder 方法
    customProductDialog(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 16 });
            Column.debugLine("entry/src/main/ets/pages/Index.ets(363:5)", "entry");
            Column.width('80%');
            Column.padding({ left: 20, right: 20 });
            Column.backgroundColor(Color.White);
            Column.borderRadius(16);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('添加自定义商品');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(364:7)", "entry");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
            Text.margin({ top: 16 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 商品名称输入
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/Index.ets(370:7)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('商品名称');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(371:9)", "entry");
            Text.fontSize(14);
            Text.fontColor('#666666');
            Text.alignSelf(ItemAlign.Start);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ text: this.customProductName, placeholder: '请输入商品名称' });
            TextInput.debugLine("entry/src/main/ets/pages/Index.ets(376:9)", "entry");
            TextInput.width('100%');
            TextInput.height(48);
            TextInput.padding({ left: 12, right: 12 });
            TextInput.borderRadius(8);
            TextInput.border({ width: 1, color: '#E5E5E5' });
            TextInput.onChange((value: string) => {
                this.customProductName = value;
            });
        }, TextInput);
        // 商品名称输入
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 商品价格输入
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/Index.ets(388:7)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('商品价格');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(389:9)", "entry");
            Text.fontSize(14);
            Text.fontColor('#666666');
            Text.alignSelf(ItemAlign.Start);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ text: this.customProductPrice, placeholder: '请输入商品价格' });
            TextInput.debugLine("entry/src/main/ets/pages/Index.ets(394:9)", "entry");
            TextInput.width('100%');
            TextInput.height(48);
            TextInput.padding({ left: 12, right: 12 });
            TextInput.borderRadius(8);
            TextInput.border({ width: 1, color: '#E5E5E5' });
            TextInput.type(InputType.Number);
            TextInput.onChange((value: string) => {
                this.customProductPrice = value;
            });
        }, TextInput);
        // 商品价格输入
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 商品图片选择
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/Index.ets(407:7)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('选择商品图片');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(408:9)", "entry");
            Text.fontSize(14);
            Text.fontColor('#666666');
            Text.alignSelf(ItemAlign.Start);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 12 });
            Row.debugLine("entry/src/main/ets/pages/Index.ets(413:9)", "entry");
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceBetween);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const image = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create(image);
                    Image.debugLine("entry/src/main/ets/pages/Index.ets(415:13)", "entry");
                    Image.width(60);
                    Image.height(60);
                    Image.borderRadius(8);
                    Image.border({
                        width: this.selectedImageIndex === index ? 3 : 1,
                        color: this.selectedImageIndex === index ? '#0A59F7' : '#E5E5E5'
                    });
                    Image.onClick(() => {
                        this.selectedImageIndex = index;
                    });
                }, Image);
            };
            this.forEachUpdateFunction(elmtId, this.productImages, forEachItemGenFunction, undefined, true, false);
        }, ForEach);
        ForEach.pop();
        Row.pop();
        // 商品图片选择
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 按钮区域
            Row.create({ space: 12 });
            Row.debugLine("entry/src/main/ets/pages/Index.ets(433:7)", "entry");
            // 按钮区域
            Row.width('100%');
            // 按钮区域
            Row.margin({ top: 8, bottom: 16 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('取消');
            Button.debugLine("entry/src/main/ets/pages/Index.ets(434:9)", "entry");
            Button.layoutWeight(1);
            Button.height(44);
            Button.fontSize(16);
            Button.fontColor('#666666');
            Button.backgroundColor('#F5F5F5');
            Button.onClick(() => {
                this.closeCustomDialog();
                this.resetDialogData();
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('添加');
            Button.debugLine("entry/src/main/ets/pages/Index.ets(445:9)", "entry");
            Button.layoutWeight(1);
            Button.height(44);
            Button.fontSize(16);
            Button.fontColor(Color.White);
            Button.backgroundColor('#0A59F7');
            Button.onClick(() => {
                this.addCustomProduct();
                this.closeCustomDialog();
                this.resetDialogData();
            });
        }, Button);
        Button.pop();
        // 按钮区域
        Row.pop();
        Column.pop();
    }
    // 对选中商品的数量进行累计求和
    @Computed
    get buyCount(): number {
        // reduce对数组内中的每个元素执行归约函数，并返回最终的归约结果
        return this.productList.reduce((sum, productItem) => productItem.checked ? (sum + productItem.count) : sum, 0);
    }
    // 商品数量变化操作
    @Provider('countChange')
    countChange: (id: string, operation: string) => void;
    // 删除选中的商品
    deleteProduct(): void {
        // filter筛选器
        // 根据条件筛选未被选中的商品，只保留未被选中的商品
        this.productList = this.productList.filter(productItem => !productItem.checked);
    }
    // 添加新商品 - 显示自定义对话框
    addProduct(): void {
        this.showCustomProductDialog();
    }
    // 监听选中商品的总数量变化，发生变化时重新计算总金额
    @Monitor('buyCount')
    buyCountChange() {
        // reduce对数组内中的每个元素执行归约函数，并返回最终的归约结果
        this.money = this.productList.reduce((sum, productItem) => productItem.checked ?
            (sum + productItem.count * productItem.price) : sum, 0);
    }
    // 全选按钮操作
    allCheckedChange(isAllChecked: boolean): void {
        for (let index = 0; index < this.productList.length; index++) {
            this.productList[index].checked = isAllChecked;
        }
    }
    ;
    // 显示自定义商品对话框
    showCustomProductDialog(): void {
        try {
            promptAction.openCustomDialog({
                builder: () => {
                    this.customProductDialog();
                },
                alignment: DialogAlignment.Center,
                maskColor: 'rgba(0, 0, 0, 0.5)',
                backgroundColor: Color.Transparent,
                cornerRadius: 16,
                width: '80%'
            }).then((dialogId: number) => {
                this.customDialogId = dialogId;
            }).catch((error: BusinessError) => {
                console.error(`打开对话框失败: ${error.code}, ${error.message}`);
            });
        }
        catch (error) {
            console.error(`打开对话框异常: ${error}`);
        }
    }
    // 关闭自定义对话框
    closeCustomDialog(): void {
        if (this.customDialogId !== 0) {
            try {
                promptAction.closeCustomDialog(this.customDialogId);
                this.customDialogId = 0;
            }
            catch (error) {
                console.error(`关闭对话框失败: ${error}`);
            }
        }
    }
    // 重置对话框数据
    resetDialogData(): void {
        this.customProductName = '';
        this.customProductPrice = '';
        this.selectedImageIndex = 0;
    }
    // 添加自定义商品
    addCustomProduct(): void {
        if (!this.customProductName.trim()) {
            promptAction.showToast({
                message: '请输入商品名称',
                duration: 2000
            });
            return;
        }
        const price = parseFloat(this.customProductPrice);
        if (isNaN(price) || price <= 0) {
            promptAction.showToast({
                message: '请输入有效的价格',
                duration: 2000
            });
            return;
        }
        const newProduct = new ProductItem(this.productImages[this.selectedImageIndex], this.customProductName, price);
        newProduct.count = 1; // 设置初始数量为1
        // 创建新数组引用，触发UI更新
        this.productList = [...this.productList, newProduct];
        promptAction.showToast({
            message: `成功添加商品: ${this.customProductName}`,
            duration: 2000
        });
        console.info(`添加自定义商品成功，商品名称: ${this.customProductName}, 价格: ${price}, 当前商品数量: ${this.productList.length}`);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(597:5)", "entry");
            Column.width('100%');
            Column.height('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // Stack为堆叠容器，可以使标题栏和总计栏堆叠在商品列表上方
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/Index.ets(599:7)", "entry");
            // Stack为堆叠容器，可以使标题栏和总计栏堆叠在商品列表上方
            Stack.height(LayoutPolicy.matchParent);
            // Stack为堆叠容器，可以使标题栏和总计栏堆叠在商品列表上方
            Stack.backgroundColor({ "id": 16777220, "type": 10001, params: [], "bundleName": "com.example.shoppingcartv2", "moduleName": "entry" });
            // Stack为堆叠容器，可以使标题栏和总计栏堆叠在商品列表上方
            Stack.ignoreLayoutSafeArea();
        }, Stack);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new 
                    // 中间 商品列表
                    ProductListView(this, { productList: this.productList }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 601, col: 9 });
                    ViewV2.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            productList: this.productList
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        productList: this.productList
                    });
                }
            }, { name: "ProductListView" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 顶部 标题栏
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(604:9)", "entry");
            // 顶部 标题栏
            Row.layoutGravity(LocalizedAlignment.TOP);
        }, Row);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new TitleView(this, {
                        deleteProduct: () => this.deleteProduct(),
                        addProduct: () => this.addProduct()
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 605, col: 11 });
                    ViewV2.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            deleteProduct: () => this.deleteProduct(),
                            addProduct: () => this.addProduct()
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
            }, { name: "TitleView" });
        }
        // 顶部 标题栏
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 底部 总计栏
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(614:9)", "entry");
            // 底部 总计栏
            Row.layoutGravity(LocalizedAlignment.BOTTOM);
        }, Row);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new StatisticsView(this, {
                        buyCount: this.buyCount,
                        money: this.money,
                        allCheckedChange: isAllChecked => this.allCheckedChange(isAllChecked)
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 615, col: 11 });
                    ViewV2.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            buyCount: this.buyCount,
                            money: this.money,
                            allCheckedChange: isAllChecked => this.allCheckedChange(isAllChecked)
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        buyCount: this.buyCount,
                        money: this.money
                    });
                }
            }, { name: "StatisticsView" });
        }
        // 底部 总计栏
        Row.pop();
        // Stack为堆叠容器，可以使标题栏和总计栏堆叠在商品列表上方
        Stack.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "ShoppingCart";
    }
}
registerNamedRoute(() => new ShoppingCart(undefined, {}), "", { bundleName: "com.example.shoppingcartv2", moduleName: "entry", pagePath: "pages/Index", pageFullPath: "entry/src/main/ets/pages/Index", integratedHsp: "false", moduleType: "followWithHap" });
