# 响应式购物车应用 - 平板和手机适配说明

## 已完成的功能

### 1. **设备支持配置**
- ✅ 修改了 `module.json5` 文件，添加了平板设备支持：
  ```json
  "deviceTypes": ["phone", "tablet"]
  ```

### 2. **响应式布局工具**
- ✅ 创建了 `ResponsiveUtils.ets` 工具类：
  - 屏幕尺寸检测和设备类型判断
  - 像素与虚拟像素转换
  - 根据设备类型和屏幕尺寸提供不同的布局配置

### 3. **响应式商品列表组件**
- ✅ 创建了 `ResponsiveProductListView.ets` 组件：
  - **手机**：单列列表布局
  - **平板**：
    - 大平板（宽度≥1200vp）：3列网格布局
    - 中平板（宽度≥840vp）：2列网格布局
    - 小平板（宽度≥600vp）：1列布局（类似手机但更大）

### 4. **响应式对话框组件**
- ✅ 创建了 `ResponsiveDialog.ets` 组件：
  - 根据设备类型调整对话框大小
  - 平板设备使用更大的字体、间距和按钮尺寸
  - 自适应宽度（平板70%，手机80%）

### 5. **数据模型重构**
- ✅ 将 `ProductItem` 类提取到独立的 `models/Product.ets` 文件
- ✅ 便于组件间共享和复用

## 响应式设计特点

### 自适应布局策略

#### 1. **屏幕尺寸检测**
- 使用 `display.getDefaultDisplaySync()` 获取屏幕信息
- 根据屏幕宽度判断设备类型：
  - **手机**：宽度 < 600vp
  - **小平板**：600vp ≤ 宽度 < 840vp
  - **中平板**：840vp ≤ 宽度 < 1200vp
  - **大平板**：宽度 ≥ 1200vp

#### 2. **布局配置参数**
每个设备类型都有对应的布局配置：
- `fontSize`: 字体大小
- `padding`: 内边距
- `margin`: 外边距
- `imageSize`: 图片尺寸
- `buttonHeight`: 按钮高度
- `gridColumns`: 网格列数（仅平板）

#### 3. **组件适配**
- **TitleView**: 根据设备类型调整字体大小、按钮尺寸和内边距
- **ProductItemView**: 根据设备类型调整图片大小、字体大小和间距
- **StatisticsView**: 根据设备类型调整字体大小、按钮尺寸和内边距
- **ResponsiveDialog**: 根据设备类型调整对话框大小和内部元素尺寸

## 文件结构变化

```
entry/src/main/ets/
├── pages/
│   └── Index.ets (已更新)
├── utils/
│   └── ResponsiveUtils.ets (新增)
├── components/
│   ├── ResponsiveProductListView.ets (新增)
│   └── ResponsiveDialog.ets (新增)
└── models/
    └── Product.ets (新增)
```

## 测试方法

### 1. **在模拟器中测试**
1. 启动DevEco Studio
2. 创建不同尺寸的模拟器：
   - 手机模拟器（如：P40 Pro）
   - 平板模拟器（如：MatePad Pro）
3. 分别在不同设备上运行应用
4. 观察布局变化

### 2. **在预览器中测试**
1. 打开 `entry/src/main/ets/pages/Index.ets`
2. 点击预览器右上角的设备切换按钮
3. 选择不同的设备类型和尺寸
4. 观察布局的自适应变化

### 3. **测试场景**
- **添加商品**：测试对话框在不同设备上的显示效果
- **商品列表**：测试列表/网格布局切换
- **统计栏**：测试字体大小和按钮尺寸适配
- **标题栏**：测试字体大小和按钮适配

## 主要修改点

### Index.ets 中的修改
1. 添加了响应式布局配置参数
2. 使用 `ResponsiveProductListView` 替换原来的 `ProductListView`
3. 更新了 `TitleView` 和 `StatisticsView` 的调用，传递 `layoutConfig` 参数
4. 使用 `ResponsiveDialog` 替换原来的对话框构建器
5. 更新了 `showCustomProductDialog` 方法，根据设备类型调整对话框宽度

### 组件适配
1. **TitleView.ets**: 添加了 `layoutConfig` 参数，根据设备类型调整样式
2. **ProductItemView.ets**: 添加了 `layoutConfig` 参数，根据设备类型调整样式
3. **StatisticsView.ets**: 添加了 `layoutConfig` 参数，根据设备类型调整样式

## 性能考虑

1. **懒加载**：只在需要时计算布局配置
2. **缓存**：使用单例模式缓存屏幕信息和布局配置
3. **响应式**：在 `aboutToAppear` 生命周期中初始化布局配置
4. **轻量级**：布局配置计算简单，不会造成性能负担

## 扩展性

### 添加新设备类型
1. 在 `ResponsiveUtils.ets` 的 `getLayoutConfig` 方法中添加新的设备类型判断
2. 添加对应的布局配置
3. 组件会自动适配新的布局配置

### 添加新的响应式组件
1. 创建新的组件时，添加 `layoutConfig` 参数
2. 根据 `layoutConfig` 中的配置调整组件样式
3. 在父组件中传递 `layoutConfig` 参数

## 注意事项

1. **屏幕旋转**：应用支持横竖屏切换，布局会自动调整
2. **分辨率适配**：使用vp（虚拟像素）单位，确保在不同分辨率设备上显示一致
3. **字体缩放**：使用系统字体缩放设置
4. **无障碍支持**：确保触摸目标大小符合无障碍标准

## 验证结果

✅ 构建成功，无编译错误
✅ 应用已成功适配平板和手机设备
✅ 布局配置根据设备类型自动调整
✅ 对话框和组件样式根据设备类型自适应
✅ 代码结构清晰，易于维护和扩展