/*
 * Copyright (c) 2023 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef RESOURCE_TABLE_H
#define RESOURCE_TABLE_H

#include<stdint.h>

namespace OHOS {
const int32_t STRING_ENTRYABILITY_DESC = 0x01000006;
const int32_t STRING_ENTRYABILITY_LABEL = 0x01000007;
const int32_t STRING_APP_NAME = 0x01000000;
const int32_t STRING_CLIFFS_OF_MOHER = 0x01000008;
const int32_t STRING_EMERALD_LAKE = 0x01000009;
const int32_t STRING_MATTERHORN = 0x0100000a;
const int32_t STRING_MODULE_DESC = 0x0100000b;
const int32_t STRING_SELECT_ALL = 0x0100000c;
const int32_t STRING_SETTLEMENT = 0x0100000d;
const int32_t STRING_SHOPPING_CART = 0x0100000e;
const int32_t STRING_SUNRISE_SNOW_MOUNTAIN = 0x0100000f;
const int32_t STRING_SWISS_SKIING = 0x01000010;
const int32_t STRING_TOTAL = 0x01000011;
const int32_t STRING_TRAVEL = 0x01000012;
const int32_t COLOR_BACKGROUND_COLOR = 0x01000004;
const int32_t COLOR_START_WINDOW_BACKGROUND = 0x01000005;
const int32_t MEDIA_1 = 0x01000014;
const int32_t MEDIA_2 = 0x01000013;
const int32_t MEDIA_3 = 0x01000018;
const int32_t MEDIA_4 = 0x01000016;
const int32_t MEDIA_5 = 0x01000015;
const int32_t MEDIA_BACKGROUND = 0x01000002;
const int32_t MEDIA_FOREGROUND = 0x01000003;
const int32_t MEDIA_LAYERED_IMAGE = 0x01000001;
const int32_t MEDIA_STARTICON = 0x01000017;
const int32_t PROFILE_MAIN_PAGES = 0x01000019;
}
#endif